var palette = {
    blue: '5949E5',
    red: 'a4303f',
    pink: 'fc768a',
    white: 'f7f4f4',
    black: '1d0e21',
    orange: 'fc8a55',
    purple: '9379af',
    yellow: 'f7da8c',
    lightGray: '9a8f97',
    gray: '475b5a',
    green: '94994E',
    vermillion: 'c3423f',
    brown: '915d5d'
}
